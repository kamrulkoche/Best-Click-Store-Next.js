
export default function Title(props) {
    return (
        <>
        <head>
        <title>{props.page}-page</title>
        
        </head>
        
        </>
    )

}